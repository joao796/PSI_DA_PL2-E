Allows SQL Server Compact 4.0 to be used with Entity Framework.
